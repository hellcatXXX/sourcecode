# NexBoot - Modified Vengance Booter Source
vengance booter remastered, to work with modern booter shells.

Use with this shell source:
https://pastebin.com/uZaQvGpa

Default Login Credentials: admin:password
